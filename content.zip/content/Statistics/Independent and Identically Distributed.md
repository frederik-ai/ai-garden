Two random variables $A$ and $B$ are independent and identically distributed if...
- they are independent
	- $P(A|B)=P(A)$
	- $P(B|A)=P(B)$
	- And thus $P(A,B)=P(A)\cdot P(B)$
- they are identically distributed
	- This means that A and B for example both follow a Gaussian distribution.