# ADAM

The ADAM optimizer achieves better performance the higher we set the batch size (at least this is what all of my experiments have shown so far).