BERT is a language-model that is not inheretly made for language generation. Instead it excels at the task of completing masked tokens in a sentence. It is primarily used for natural language understanding (named entity recognition (NER), part-of-speech tagging (POS), sentiment analysis, ...).

In comparison to GTP, BERT cannot be prompted.