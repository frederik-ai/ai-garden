---
title: Welcome 👋
---
My name is Frederik and these are my personal lecture notes that I take for my [university courses](https://ekvv.uni-bielefeld.de/sinfo/publ/master-as/intsys;lang=EN). I am a M.Sc. student in the field of AI at University of Bielefeld, Germany. If you are, like me, interested in Computer Vision, Machine Learning, etc. this site might be interesting to you.

This site is always work in progress. Some notes may not be finished yet.

[<img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white">](https://www.linkedin.com/in/frederik-esau-602008226/)